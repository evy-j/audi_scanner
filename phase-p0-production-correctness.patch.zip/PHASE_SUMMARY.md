# Phase P0 Production Correctness Summary

This patch implements only P0 reliability and production-faithfulness. It does not add autonomous agents, fake AI systems, fake exploit simulation, or dummy vulnerabilities.

## Implemented

- Persisted normalized vulnerabilities into PostgreSQL during findings normalization.
- Added persisted analyzer runs with analyzer/tool name, status, timestamps, error text, raw artifact key, raw artifact checksum, standardized artifact key, duration, exit code, trace ID, and correlation ID.
- Added durable scan events in PostgreSQL for lifecycle transitions, including queued, preparing, analyzing, normalizing, scoring, reporting, completed, failed, canceled, and partial.
- Added transactional outbox for scan creation so database writes and queue enqueue cannot diverge.
- Added API outbox relay with retry/backoff and max-attempt handling.
- Added durable artifact abstraction:
  - local filesystem backend for development
  - S3/R2-compatible backend with AWS SigV4 PUT/GET/HEAD/List support
  - local materialization for Docker scanner workspaces
- Updated worker finalization so terminal scan status is persisted to PostgreSQL.
- Added partial-completion semantics: if at least one analyzer succeeds and another is not assessed/failed after final retry, the scan finishes as `PARTIAL`.
- Added analyzer failure semantics: `TOOL_NOT_INSTALLED`, `PROVIDER_NOT_CONFIGURED`, `TIMEOUT`, `FAILED`, `NOT_ASSESSED`, `CANCELED`.
- Updated report UI to read persisted findings from the API by scan ID.
- Marked unsupported frontend target modes as Not Implemented and rejected unsupported backend target modes before queueing.
- Added OpenTelemetry-ready `traceId` and `correlationId` response headers, error payload fields, logs, queue payloads, events, and persisted records.

## Migration

New Prisma migration:

```text
packages/database/prisma/migrations/20260523150000_p0_production_correctness/migration.sql
```

## Commands

Install dependencies:

```bash
npm install
```

Generate Prisma client:

```bash
npm run db:generate
```

Run database migration in local development:

```bash
npm run db:migrate:dev
```

Deploy database migration in staging/production:

```bash
npm run db:deploy
```

Run API:

```bash
npm run dev:api
```

Run worker:

```bash
npm run dev:worker
```

Run web:

```bash
npm run dev:web
```

Run typecheck:

```bash
npm run typecheck
```

Run tests:

```bash
npm test
```

Build:

```bash
npm run build
```

## Verification Completed

```bash
npm run db:generate
npm run typecheck
```

`npm run db:generate` required elevated filesystem access on Windows because Prisma probes the user temp/home directory outside the workspace.
