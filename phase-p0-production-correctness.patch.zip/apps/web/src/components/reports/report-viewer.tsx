"use client";

import * as React from "react";
import { Download, FileText, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AuditScannerApiClient, hasWorkspaceConfig } from "@/lib/api-client";
import { useWorkspaceConfig } from "@/hooks/use-workspace-config";
import { formatDateTime, toNumber } from "@/lib/utils";
import type { AuditReport, Vulnerability } from "@/types/api";

export function ReportViewer({ reportId }: { reportId: string }) {
  const { config } = useWorkspaceConfig();
  const [report, setReport] = React.useState<AuditReport | null>(null);
  const [reports, setReports] = React.useState<AuditReport[]>([]);
  const [vulnerabilities, setVulnerabilities] = React.useState<Vulnerability[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!hasWorkspaceConfig(config)) {
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const client = new AuditScannerApiClient(config);
        let selectedReport: AuditReport | null = null;
        if (reportId === "latest") {
          const list = await client.listReports(10);
          setReports(list);
          selectedReport = list[0] ?? null;
        } else {
          selectedReport = await client.getReport(reportId);
        }
        setReport(selectedReport);
        setVulnerabilities(
          selectedReport
            ? await client.listVulnerabilities({ scanId: selectedReport.scanId, limit: 100 })
            : []
        );
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Unable to load report");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [config, reportId]);

  return (
    <AppShell>
      <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <Badge variant="blue" className="mb-3">Audit reports</Badge>
          <h1 className="text-3xl font-semibold tracking-tight text-white">Report intelligence</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
            Executive findings, risk scoring, remediation guidance, and PDF export metadata.
          </p>
        </div>
        <Button variant="secondary" disabled={!report?.pdfStorageKey}>
          <Download className="h-4 w-4" />
          PDF artifact
        </Button>
      </div>

      {error ? <div className="mb-4 rounded-md border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-100">{error}</div> : null}

      {loading ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Skeleton className="h-[520px]" />
          <Skeleton className="h-[320px]" />
        </div>
      ) : report ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle>{report.title}</CardTitle>
                  <p className="mt-2 text-sm text-muted-foreground">{report.reportNumber ?? report.id}</p>
                </div>
                <Badge variant={toNumber(report.riskScore) >= 70 ? "red" : "default"}>{report.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6 grid gap-3 sm:grid-cols-3">
                <Stat label="Risk score" value={toNumber(report.riskScore).toFixed(0)} />
                <Stat label="Version" value={`v${report.version}`} />
                <Stat label="Generated" value={formatDateTime(report.generatedAt)} />
              </div>
              <section className="rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Executive summary
                </div>
                <p className="text-sm leading-7 text-slate-300">
                  {report.executiveSummary ?? "The report record does not include an executive summary."}
                </p>
              </section>
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-amber-200" />
                  Persisted findings
                </div>
                <div className="space-y-3">
                  {vulnerabilities.length > 0 ? (
                    vulnerabilities.slice(0, 12).map((vulnerability) => (
                      <div key={vulnerability.id} className="rounded-md border border-white/10 bg-black/20 p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="text-sm font-medium text-white">{vulnerability.title}</div>
                            <div className="mt-1 text-xs text-muted-foreground">
                              {vulnerability.filePath ?? "Unknown file"}
                              {vulnerability.lineStart ? `:${vulnerability.lineStart}` : ""}
                            </div>
                          </div>
                          <Badge variant={vulnerability.severity === "CRITICAL" || vulnerability.severity === "HIGH" ? "red" : "default"}>
                            {vulnerability.severity}
                          </Badge>
                        </div>
                        {vulnerability.remediation ? (
                          <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted-foreground">
                            {vulnerability.remediation}
                          </p>
                        ) : null}
                      </div>
                    ))
                  ) : (
                    <div className="text-sm text-muted-foreground">No persisted findings for this report scan.</div>
                  )}
                </div>
              </section>
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <FileText className="h-4 w-4 text-sky-200" />
                  Artifacts
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div>Markdown: {report.storageKey ?? "Not available"}</div>
                  <div>PDF: {report.pdfStorageKey ?? "Not available"}</div>
                  <div>Checksum: {report.checksumSha256 ?? "Not available"}</div>
                </div>
              </section>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(reports.length > 0 ? reports : [report]).map((item) => (
                <div key={item.id} className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="text-sm font-medium text-white">{item.title}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{formatDateTime(item.createdAt)}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="p-10 text-center text-sm text-muted-foreground">No report available</CardContent>
        </Card>
      )}
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-white/10 bg-white/6 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-semibold text-white">{value}</div>
    </div>
  );
}
