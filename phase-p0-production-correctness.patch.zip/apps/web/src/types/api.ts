export type ScanStatus =
  | "DRAFT"
  | "QUEUED"
  | "PREPARING"
  | "RUNNING"
  | "ANALYZING"
  | "NORMALIZING"
  | "SCORING"
  | "REPORTING"
  | "COMPLETED"
  | "PARTIAL"
  | "FAILED"
  | "CANCELED"
  | "EXPIRED";

export type Severity = "INFORMATIONAL" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface Scan {
  id: string;
  organizationId: string;
  chainId?: string | null;
  contractId?: string | null;
  type: string;
  status: ScanStatus;
  priority: "LOW" | "NORMAL" | "HIGH" | "CRITICAL";
  title?: string | null;
  progress: number;
  riskScore: number | string;
  queuedAt?: string | null;
  startedAt?: string | null;
  completedAt?: string | null;
  canceledAt?: string | null;
  createdAt: string;
  updatedAt: string;
  targets?: ScanTarget[];
  vulnerabilities?: Vulnerability[];
  reports?: AuditReport[];
  analyzerRuns?: AnalyzerRun[];
  events?: ScanEvent[];
}

export interface ScanTarget {
  id: string;
  targetType: string;
  contractAddress?: string | null;
  normalizedAddress?: string | null;
  repositoryUrl?: string | null;
  artifactStorageKey?: string | null;
}

export interface Vulnerability {
  id: string;
  scanId: string;
  analyzer: string;
  externalRuleId?: string | null;
  fingerprint: string;
  category: string;
  title: string;
  description?: string | null;
  severity: Severity;
  confidence: string;
  status: string;
  filePath?: string | null;
  contractName?: string | null;
  functionName?: string | null;
  lineStart?: number | null;
  lineEnd?: number | null;
  remediation?: string | null;
  createdAt: string;
}

export interface AnalyzerRun {
  id: string;
  scanId: string;
  analyzer: string;
  toolName: string;
  status: string;
  startedAt: string;
  finishedAt?: string | null;
  error?: string | null;
  rawArtifactKey?: string | null;
  rawArtifactChecksumSha256?: string | null;
  standardizedArtifactKey?: string | null;
}

export interface ScanEvent {
  id: string;
  scanId: string;
  type: string;
  status: ScanStatus;
  progress: number;
  message: string;
  traceId?: string | null;
  correlationId?: string | null;
  emittedAt: string;
}

export interface AuditReport {
  id: string;
  scanId: string;
  organizationId: string;
  reportNumber?: string | null;
  version: number;
  status: string;
  title: string;
  executiveSummary?: string | null;
  riskScore: number | string;
  storageKey?: string | null;
  pdfStorageKey?: string | null;
  checksumSha256?: string | null;
  generatedAt?: string | null;
  publishedAt?: string | null;
  createdAt: string;
}

export interface Organization {
  id: string;
  name: string;
  slug: string;
  status: string;
  billingEmail?: string | null;
  createdAt: string;
}

export interface ApiKeyRecord {
  id: string;
  organizationId: string;
  name: string;
  keyPrefix: string;
  status: string;
  scopes: string[];
  lastUsedAt?: string | null;
  expiresAt?: string | null;
  createdAt: string;
  revokedAt?: string | null;
}

export interface CreatedApiKey extends ApiKeyRecord {
  apiKey: string;
}

export interface ScanProgressEvent {
  eventId: string;
  sequence: number;
  type: string;
  scanId: string;
  organizationId: string;
  status: ScanStatus | string;
  progress: number;
  message: string;
  jobId?: string;
  queueName?: string;
  workerId?: string;
  data?: Record<string, unknown>;
  emittedAt: string;
}
