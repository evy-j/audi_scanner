"use client";

import * as React from "react";
import { AuditScannerApiClient, hasWorkspaceConfig, type WorkspaceConfig } from "@/lib/api-client";
import type { AuditReport, Scan, Vulnerability } from "@/types/api";

export interface DashboardData {
  scans: Scan[];
  vulnerabilities: Vulnerability[];
  reports: AuditReport[];
}

export function useDashboardData(config: WorkspaceConfig) {
  const [data, setData] = React.useState<DashboardData>({
    scans: [],
    vulnerabilities: [],
    reports: []
  });
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const refresh = React.useCallback(async () => {
    if (!hasWorkspaceConfig(config)) {
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const client = new AuditScannerApiClient(config);
      const [scans, vulnerabilities, reports] = await Promise.all([
        client.listScans(25),
        client.listVulnerabilities({ limit: 100 }),
        client.listReports(20)
      ]);
      setData({ scans, vulnerabilities, reports });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Unable to load dashboard data");
    } finally {
      setLoading(false);
    }
  }, [config]);

  React.useEffect(() => {
    void refresh();
  }, [refresh]);

  return { data, loading, error, refresh };
}
