import { prisma } from "@audit-scanner/database";
import type {
  AnalyzerRunStatus,
  AnalyzerType,
  Prisma,
  VulnerabilityCategory
} from "@prisma/client";
import type {
  AggregatedVulnerability,
  VulnerabilityNormalizationOutput
} from "@audit-scanner/scanner-core";
import type { AnalyzerJobData, AnalyzerName } from "@audit-scanner/shared/queues/scan-jobs";

export interface StartedAnalyzerRun {
  id: string;
  startedAt: Date;
}

export class ScanPersistenceService {
  async startAnalyzerRun(data: AnalyzerJobData): Promise<StartedAnalyzerRun> {
    const startedAt = new Date();
    const run = await prisma.analyzerRun.create({
      data: {
        scanId: data.scanId,
        organizationId: data.organizationId,
        analyzer: toAnalyzerType(data.analyzer),
        toolName: data.analyzer,
        status: "RUNNING",
        startedAt,
        traceId: data.traceId,
        correlationId: data.correlationId ?? null,
        metadata: {
          preparedArtifactKey: data.preparedArtifactKey,
          scannerImage: data.scannerImage,
          timeoutMs: data.timeoutMs
        }
      }
    });

    return { id: run.id, startedAt };
  }

  finalizeAnalyzerRun(input: {
    analyzerRunId: string;
    status: AnalyzerRunStatus;
    startedAt: Date;
    exitCode?: number | null | undefined;
    durationMs?: number | undefined;
    error?: string | undefined;
    rawArtifactKey?: string | undefined;
    rawArtifactChecksumSha256?: string | undefined;
    standardizedArtifactKey?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
  }) {
    return prisma.analyzerRun.update({
      where: { id: input.analyzerRunId },
      data: {
        status: input.status,
        finishedAt: new Date(),
        durationMs: input.durationMs ?? Math.max(0, Date.now() - input.startedAt.getTime()),
        exitCode: input.exitCode ?? null,
        error: input.error ?? null,
        rawArtifactKey: input.rawArtifactKey ?? null,
        rawArtifactChecksumSha256: input.rawArtifactChecksumSha256 ?? null,
        standardizedArtifactKey: input.standardizedArtifactKey ?? null,
        ...(input.metadata ? { metadata: toJsonObject(input.metadata) } : {})
      }
    });
  }

  async persistNormalizedVulnerabilities(output: VulnerabilityNormalizationOutput): Promise<number> {
    if (output.vulnerabilities.length === 0) {
      return 0;
    }

    await prisma.$transaction(
      output.vulnerabilities.map((vulnerability) =>
        prisma.vulnerability.upsert({
          where: {
            scanId_fingerprint: {
              scanId: output.scanId,
              fingerprint: vulnerability.fingerprint
            }
          },
          update: toVulnerabilityUpdate(vulnerability),
          create: {
            scanId: output.scanId,
            status: "OPEN",
            ...toVulnerabilityCreate(vulnerability)
          }
        })
      )
    );

    return output.vulnerabilities.length;
  }
}

export function toAnalyzerType(analyzer: AnalyzerName): AnalyzerType {
  switch (analyzer) {
    case "slither":
      return "SLITHER";
    case "mythril":
      return "MYTHRIL";
    case "semgrep":
      return "SEMGREP";
    case "foundry":
      return "FOUNDRY";
  }
}

function toVulnerabilityCreate(
  vulnerability: AggregatedVulnerability
): Omit<Prisma.VulnerabilityUncheckedCreateInput, "id" | "scanId" | "status" | "createdAt" | "updatedAt"> {
  const primary = vulnerability.primaryLocation;

  return {
    analyzer: toAnalyzerType(vulnerability.analyzers[0] ?? "semgrep"),
    externalRuleId: vulnerability.findingIds[0] ?? null,
    fingerprint: vulnerability.fingerprint,
    category: toPrismaCategory(vulnerability.category),
    title: vulnerability.title.slice(0, 240),
    description: vulnerability.description,
    severity: vulnerability.severity,
    confidence: vulnerability.confidence,
    filePath: primary.filePath ?? null,
    contractName: primary.contractName ?? null,
    functionName: primary.functionName ?? null,
    lineStart: primary.lineStart ?? null,
    lineEnd: primary.lineEnd ?? null,
    evidence: toJsonObject({
      evidence: vulnerability.evidence,
      locations: vulnerability.locations
    }),
    remediation: vulnerability.remediation ?? null,
    referenceUrls: vulnerability.references,
    metadata: toJsonObject({
      riskScore: vulnerability.riskScore,
      analyzerCount: vulnerability.analyzerCount,
      analyzers: vulnerability.analyzers,
      findingIds: vulnerability.findingIds,
      cweIds: vulnerability.cweIds,
      swcIds: vulnerability.swcIds,
      owaspSmartContractTop10: vulnerability.owaspSmartContractTop10,
      owaspWebTop10: vulnerability.owaspWebTop10
    })
  };
}

function toVulnerabilityUpdate(
  vulnerability: AggregatedVulnerability
): Prisma.VulnerabilityUncheckedUpdateInput {
  const { fingerprint: _fingerprint, ...data } = toVulnerabilityCreate(vulnerability);
  return data;
}

function toPrismaCategory(category: AggregatedVulnerability["category"]): VulnerabilityCategory {
  switch (category) {
    case "REENTRANCY":
    case "INTEGER_OVERFLOW":
    case "TX_ORIGIN":
    case "ACCESS_CONTROL":
    case "DELEGATECALL":
    case "ORACLE_MANIPULATION":
    case "FLASH_LOAN":
    case "SELFDESTRUCT":
    case "UPGRADEABILITY":
    case "UNSAFE_EXTERNAL_CALL":
    case "HONEYPOT":
    case "RUG_PULL":
    case "SUSPICIOUS_OWNERSHIP":
    case "GAS_OPTIMIZATION":
    case "INSECURE_RANDOMNESS":
    case "DENIAL_OF_SERVICE":
    case "BUSINESS_LOGIC":
    case "OTHER":
      return category;
  }
}

function toJsonObject(value: Record<string, unknown>): Prisma.InputJsonObject {
  return value as Prisma.InputJsonObject;
}
