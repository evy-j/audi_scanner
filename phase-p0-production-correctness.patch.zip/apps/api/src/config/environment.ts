import { z } from "zod";

const DEVELOPMENT_ACCESS_SECRET = "development-access-secret-change-me-32";
const DEVELOPMENT_REFRESH_SECRET = "development-refresh-secret-change-me-32";
const DEVELOPMENT_API_KEY_SECRET = "development-api-key-secret-change-me-32";

const csv = z
  .string()
  .default("")
  .transform((value) =>
    value
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean)
  );

const envSchema = z
  .object({
    NODE_ENV: z
      .enum(["development", "test", "staging", "production"])
      .default("development"),
    PORT: z.coerce.number().int().positive().default(4000),
    TRUST_PROXY_HOPS: z.coerce.number().int().nonnegative().default(1),
    HTTP_REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().default(60_000),
    HTTP_HEADERS_TIMEOUT_MS: z.coerce.number().int().positive().default(65_000),
    HTTP_KEEP_ALIVE_TIMEOUT_MS: z.coerce.number().int().positive().default(5_000),
    HTTP_SHUTDOWN_GRACE_MS: z.coerce.number().int().positive().default(15_000),
    LOG_LEVEL: z
      .enum(["trace", "debug", "info", "warn", "error", "fatal", "silent"])
      .default("info"),
    API_BASE_PATH: z.string().default("/api/v1"),
    CORS_ORIGINS: csv,
    REALTIME_WS_PATH: z.string().default("/api/v1/realtime"),
    REALTIME_HEARTBEAT_INTERVAL_MS: z.coerce.number().int().positive().default(25_000),
    REALTIME_MAX_SUBSCRIPTIONS_PER_CONNECTION: z.coerce.number().int().positive().default(50),
    REALTIME_REPLAY_MAX_EVENTS: z.coerce.number().int().positive().max(500).default(250),
    REALTIME_MAX_MESSAGE_BYTES: z.coerce.number().int().positive().default(65_536),
    REALTIME_MAX_BUFFERED_BYTES: z.coerce.number().int().positive().default(1_048_576),
    REALTIME_RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
    REALTIME_RATE_LIMIT_MAX_CONNECTIONS: z.coerce.number().int().positive().default(30),
    JWT_ACCESS_SECRET: z.string().min(32).default(DEVELOPMENT_ACCESS_SECRET),
    JWT_REFRESH_SECRET: z.string().min(32).default(DEVELOPMENT_REFRESH_SECRET),
    JWT_ACCESS_TTL_SECONDS: z.coerce.number().int().positive().default(15 * 60),
    JWT_REFRESH_TTL_SECONDS: z.coerce.number().int().positive().default(30 * 24 * 60 * 60),
    API_KEY_HASH_SECRET: z.string().min(32).default(DEVELOPMENT_API_KEY_SECRET),
    REDIS_URL: z.string().url().default("redis://localhost:6379"),
    REDIS_KEY_PREFIX: z.string().default("audit-scanner"),
    REDIS_ENABLE_TLS: z.coerce.boolean().default(false),
    REDIS_COMMAND_TIMEOUT_MS: z.coerce.number().int().positive().default(10_000),
    PASSWORD_MIN_LENGTH: z.coerce.number().int().positive().default(12),
    RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
    RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(300),
    AUTH_RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(20),
    SCAN_RATE_LIMIT_MAX_REQUESTS: z.coerce.number().int().positive().default(30),
    SCAN_ADMISSION_MAX_QUEUED_JOBS: z.coerce.number().int().positive().default(5_000),
    OUTBOX_RELAY_INTERVAL_MS: z.coerce.number().int().positive().default(2_000),
    OUTBOX_RELAY_BATCH_SIZE: z.coerce.number().int().positive().max(100).default(25),
    OUTBOX_RELAY_MAX_ATTEMPTS: z.coerce.number().int().positive().default(10)
  })
  .superRefine((value, context) => {
    if (value.NODE_ENV !== "production") {
      return;
    }

    if (value.CORS_ORIGINS.length === 0) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["CORS_ORIGINS"],
        message: "CORS_ORIGINS must be explicitly set in production"
      });
    }

    for (const [path, secret, developmentValue] of [
      ["JWT_ACCESS_SECRET", value.JWT_ACCESS_SECRET, DEVELOPMENT_ACCESS_SECRET],
      ["JWT_REFRESH_SECRET", value.JWT_REFRESH_SECRET, DEVELOPMENT_REFRESH_SECRET],
      ["API_KEY_HASH_SECRET", value.API_KEY_HASH_SECRET, DEVELOPMENT_API_KEY_SECRET]
    ] as const) {
      if (secret === developmentValue) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: [path],
          message: `${path} must not use the development default in production`
        });
      }
    }
  });

export type ApiEnvironment = z.infer<typeof envSchema>;

export const env: ApiEnvironment = envSchema.parse(process.env);
