import { randomBytes, randomUUID } from "node:crypto";
import { ApiError } from "../../common/errors/api-error.js";
import { env } from "../../config/environment.js";
import { logger } from "../../common/logging/logger.js";
import { redis, redisKey } from "../../infra/queues/redis.js";
import { ScanQueueProducer } from "../../infra/queues/scan-queue.producer.js";
import { ScanOutboxRelay } from "../../infra/outbox/scan-outbox.relay.js";
import { publishScanProgressEvent } from "../../infra/realtime/scan-progress-event.publisher.js";
import { ScansRepository } from "./scans.repository.js";
import type { ScanOrchestratorJobData } from "@audit-scanner/shared/queues/scan-jobs";
import type { CreateScanInput, ListScansQuery } from "./scans.schemas.js";

export class ScansService {
  constructor(
    private readonly repository = new ScansRepository(),
    private readonly queueProducer = new ScanQueueProducer(),
    private readonly outboxRelay = new ScanOutboxRelay(queueProducer)
  ) {}

  async create(
    input: CreateScanInput,
    userId: string,
    context: { traceId?: string | undefined; correlationId?: string | undefined } = {}
  ) {
    this.assertSupportedScanMode(input);
    await this.assertAdmissionCapacity();
    const traceId = context.traceId ?? randomBytes(16).toString("hex");
    const provisionalScanId = randomUUID();
    const queueJob: ScanOrchestratorJobData = {
      scanId: provisionalScanId,
      organizationId: input.organizationId,
      requestedByUserId: userId,
      traceId,
      ...(context.correlationId ? { correlationId: context.correlationId } : {}),
      priority: input.priority,
      target: {
        type: input.target.type,
        ...(input.target.chainId ? { chainId: input.target.chainId } : {}),
        ...(input.target.address ? { address: input.target.address } : {}),
        ...(input.target.repositoryUrl ? { repositoryUrl: input.target.repositoryUrl } : {}),
        ...(input.target.artifactKey ? { artifactKey: input.target.artifactKey } : {})
      },
      analyzers: input.analyzers
    };

    const scan = await this.repository.create(input, userId, {
      ...queueJob,
      scanId: provisionalScanId
    });

    await this.outboxRelay.processPending().catch((error) => {
      logger.warn({ err: error, scanId: scan.id, traceId }, "scan outbox relay deferred");
    });
    await publishScanProgressEvent({
      type: "scan.queued",
      scanId: scan.id,
      organizationId: scan.organizationId,
      status: "QUEUED",
      progress: 0,
      message: "Scan was queued",
      traceId,
      correlationId: context.correlationId,
      data: {
        priority: input.priority,
        analyzers: input.analyzers
      }
    }).catch((error) => {
      logger.warn({ err: error, scanId: scan.id }, "queued realtime event publish failed");
    });

    return scan;
  }

  list(query: ListScansQuery) {
    return this.repository.list(query);
  }

    private async assertAdmissionCapacity(): Promise<void> {
    const queuedJobs = await this.queueProducer.getAdmissionDepth();
    if (queuedJobs >= env.SCAN_ADMISSION_MAX_QUEUED_JOBS) {
      throw ApiError.serviceUnavailable("Scan admission is temporarily saturated", {
        queuedJobs,
        limit: env.SCAN_ADMISSION_MAX_QUEUED_JOBS
      });
    }
  }

  private assertSupportedScanMode(input: CreateScanInput): void {
    if (input.target.type !== "SOURCE") {
      throw ApiError.notImplemented(
        `${input.target.type} scans are not implemented in the production-correct P0 pipeline. Use SOURCE with an artifactKey.`
      );
    }
  }

  async get(scanId: string, organizationId?: string | undefined) {
    const scan = await this.repository.findById(scanId);
    if (!scan || (organizationId && scan.organizationId !== organizationId)) {
      throw ApiError.notFound("Scan");
    }

    return scan;
  }

  async cancel(scanId: string, organizationId?: string | undefined, requestedBy?: string | undefined) {
    const scan = await this.get(scanId, organizationId);

    if (["COMPLETED", "FAILED", "CANCELED"].includes(scan.status)) {
      throw ApiError.conflict("Scan is already finalized");
    }

    await redis.set(
      redisKey("scan", scanId, "cancel"),
      JSON.stringify({
        scanId,
        reason: "User requested cancellation",
        requestedBy,
        requestedAt: new Date().toISOString()
      }),
      "EX",
      24 * 60 * 60
    );

    const updated = await this.repository.updateStatus(scanId, {
      status: "CANCELED",
      canceledAt: new Date()
    });
    const traceId = getMetadataString(scan.metadata, "traceId");
    const correlationId = getMetadataString(scan.metadata, "correlationId");
    await this.repository.recordScanEvent({
      scanId,
      organizationId: scan.organizationId,
      type: "scan.canceled",
      status: "CANCELED",
      progress: 100,
      message: "Scan cancellation was requested",
      traceId,
      correlationId,
      data: {
        ...(requestedBy ? { requestedBy } : {})
      }
    });

    await publishScanProgressEvent({
      type: "scan.canceled",
      scanId,
      organizationId: scan.organizationId,
      status: "CANCELED",
      progress: 100,
      message: "Scan cancellation was requested",
      traceId,
      correlationId,
      data: {
        ...(requestedBy ? { requestedBy } : {})
      }
    }).catch((error) => {
      logger.warn({ err: error, scanId }, "canceled realtime event publish failed");
    });

    return updated;
  }
}

function getMetadataString(metadata: unknown, key: string): string | undefined {
  if (!metadata || typeof metadata !== "object" || !(key in metadata)) {
    return undefined;
  }
  const value = (metadata as Record<string, unknown>)[key];
  return typeof value === "string" ? value : undefined;
}
