import express from "express";
import cors from "cors";
import helmet from "helmet";
import { prisma } from "./infra/prisma/prisma.js";
import { env } from "./config/environment.js";
import { requestIdMiddleware } from "./common/middleware/request-id.middleware.js";
import { httpLoggerMiddleware } from "./common/middleware/http-logger.middleware.js";
import { globalRateLimit } from "./common/middleware/rate-limit.middleware.js";
import { errorHandler } from "./common/errors/error-handler.js";
import { ApiError } from "./common/errors/api-error.js";
import { redis } from "./infra/queues/redis.js";
import { v1Router } from "./routes/v1/index.js";

export function createApiApp() {
  const app = express();

  app.disable("x-powered-by");
  app.set("trust proxy", env.TRUST_PROXY_HOPS);

  app.use(requestIdMiddleware);
  app.use(httpLoggerMiddleware);
  app.use(
    helmet({
      crossOriginResourcePolicy: { policy: "same-site" }
    })
  );
  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin || isAllowedCorsOrigin(origin)) {
          callback(null, true);
          return;
        }

        callback(ApiError.forbidden("CORS origin denied"));
      },
      credentials: true
    })
  );
  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: false, limit: "100kb" }));
  app.use(globalRateLimit);

  app.get("/health", (_req, res) => {
    res.json({
      status: "ok",
      service: "audit-scanner-api",
      timestamp: new Date().toISOString()
    });
  });

  app.get("/ready", async (_req, res) => {
    const checks = await Promise.allSettled([prisma.$queryRaw`SELECT 1`, redis.ping()]);
    const databaseReady = checks[0].status === "fulfilled";
    const redisReady = checks[1].status === "fulfilled";
    const ready = databaseReady && redisReady;

    res.status(ready ? 200 : 503).json({
      status: ready ? "ready" : "not_ready",
      service: "audit-scanner-api",
      checks: {
        database: databaseReady ? "ok" : "failed",
        redis: redisReady ? "ok" : "failed"
      },
      timestamp: new Date().toISOString()
    });
  });

  app.use(env.API_BASE_PATH, v1Router);
  app.use((_req, res) => {
    res.status(404).json({
      error: {
        code: "NOT_FOUND",
        message: "Route was not found",
        requestId: _req.id,
        traceId: _req.traceId,
        correlationId: _req.correlationId
      }
    });
  });
  app.use(errorHandler);

  return app;
}

function isAllowedCorsOrigin(origin: string): boolean {
  if (env.CORS_ORIGINS.includes(origin)) {
    return true;
  }

  return env.NODE_ENV !== "production" && env.CORS_ORIGINS.length === 0;
}
