# Phase P2A Evidence Review Workflow + Audit Operations Summary

This patch implements P2A only. It does not add AI agents, exploit simulation, AST/CFG analysis, fake findings, or automatic confirmation.

## Implemented

- Added a real review workflow on top of P1 evidence-backed findings.
- Added project-scoped audit operations with optional `scan.projectId`.
- Added persisted review state:
  - `UNREVIEWED`
  - `NEEDS_REVIEW`
  - `ACCEPTED`
  - `FALSE_POSITIVE`
  - `RISK_ACCEPTED`
  - `FIXED`
  - `WONT_FIX`
  - `DUPLICATE`
  - `SUPPRESSED`
- Added persisted review actions:
  - `STATUS_CHANGED`
  - `COMMENT_ADDED`
  - `ASSIGNED`
  - `SUPPRESSED`
  - `UNSUPPRESSED`
  - `SEVERITY_OVERRIDDEN`
  - `CONFIDENCE_OVERRIDDEN`
  - `BASELINE_MARKED`
  - `EXPORT_REQUESTED`
- Added review/audit models:
  - `Project`
  - `FindingReview`
  - `FindingReviewEvent`
  - `FindingSuppressionRule`
  - `FindingBaseline`
  - `FindingComment`
  - `FindingAssignment`
  - `CodeOwnerRule`
- Added repository-backed review APIs:
  - `GET /api/v1/scans/:scanId/review-summary`
  - `GET /api/v1/findings/:findingId/review`
  - `POST /api/v1/findings/:findingId/review/status`
  - `POST /api/v1/findings/:findingId/comments`
  - `POST /api/v1/findings/:findingId/assign`
  - `POST /api/v1/findings/:findingId/suppress`
  - `POST /api/v1/findings/:findingId/unsuppress`
  - `GET /api/v1/projects/:projectId/suppression-rules`
  - `POST /api/v1/projects/:projectId/suppression-rules`
  - `DELETE /api/v1/projects/:projectId/suppression-rules/:ruleId`
  - `GET /api/v1/scans/:scanId/baseline-comparison`
  - `GET /api/v1/projects/:projectId/codeowners`
  - `POST /api/v1/projects/:projectId/codeowners`
  - `DELETE /api/v1/projects/:projectId/codeowners/:ruleId`
  - `GET /api/v1/scans/:scanId/export/sarif`

## Suppression Behavior

- Suppression never deletes findings.
- Suppression marks matching findings as `SUPPRESSED` in review state and vulnerability status.
- Suppression writes `FindingReviewEvent` audit rows with previous and new values.
- Unsuppression restores the previous review state from `statusBeforeSuppression`.
- Suppression rules match deterministically by analyzer, rule ID, file path, function name, fingerprint, severity, and message substring.

## Baseline Behavior

- Baseline comparison uses P1 stable fingerprints.
- It reports new, existing, fixed, regressed, and suppressed findings.
- If `baseScanId` is omitted, the API compares against the latest earlier completed scan for the same project.
- Comparison rows are persisted idempotently in `FindingBaseline`.

## Code Owner Routing

- Added CODEOWNERS-style path pattern rules.
- Rules store owner name, email, team, and optional severity threshold.
- Creating a rule auto-assigns matching persisted findings and writes assignment audit events.

## SARIF Export

- Added SARIF 2.1.0 export for persisted findings.
- SARIF includes analyzer tool name, rule ID, severity, message, file/source range when present, fingerprint, confidence state, and review status.
- Suppressed findings are excluded by default and included with suppression metadata when `includeSuppressed=true`.
- No fake locations are emitted.

## Frontend Changes

- Report viewer now reads persisted review data from the API.
- Added review status badges.
- Added filters for review status, severity, confidence, and analyzer.
- Added finding review panel with status change, comment, assignment, suppression, and unsuppression actions.
- Added persisted audit trail timeline with actor, action, previous value, new value, reason, and timestamp.
- Added baseline comparison summary.
- Added SARIF export button.

## Database Migration

New Prisma migration:

```text
packages/database/prisma/migrations/20260523203000_p2a_review_workflow/migration.sql
```

## Tests Added

- Review status change persists a review event.
- Suppression rule marks matching findings suppressed.
- Unsuppression restores previous review state.
- Baseline comparison detects new, existing, fixed, and regressed findings.
- SARIF export contains persisted finding source ranges.
- Code owner rule assigns matching findings.
- Review API returns repository-backed data.

## Verification Completed

```bash
npm run db:generate
npm run typecheck
npm test
npm run build
```

`npm run db:generate` required elevated filesystem access on Windows because Prisma probes `C:\Users\nk148` outside the workspace.

## Commands

Install dependencies:

```bash
npm install
```

Generate Prisma client:

```bash
npm run db:generate
```

Run database migration in local development:

```bash
npm run db:migrate:dev
```

Deploy database migration in staging/production:

```bash
npm run db:deploy
```

Run API:

```bash
npm run dev:api
```

Run worker:

```bash
npm run dev:worker
```

Run web:

```bash
npm run dev:web
```

Run typecheck:

```bash
npm run typecheck
```

Run tests:

```bash
npm test
```

Build:

```bash
npm run build
```

## Limitations

- Existing scans without a real `projectId` cannot use project-scoped review operations; the API returns a bad request instead of fabricating a project.
- P2A does not mark findings `CONFIRMED` automatically.
- P2A does not add AI triage, exploit simulation, or AST/CFG analysis.
- CODEOWNERS matching is deterministic glob matching only.

## Recommended P2B

Implement AST/CFG/source-map deep analysis: source map normalization, function boundary extraction, call graph generation, dataflow hints, richer line-to-node evidence, and analyzer evidence alignment across source and bytecode.
