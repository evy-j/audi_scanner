import { Router } from "express";
import { authRoutes } from "../../modules/auth/auth.routes.js";
import { organizationRoutes } from "../../modules/organizations/organizations.routes.js";
import { scanRoutes } from "../../modules/scans/scans.routes.js";
import { reportRoutes } from "../../modules/reports/reports.routes.js";
import { vulnerabilityRoutes } from "../../modules/vulnerabilities/vulnerabilities.routes.js";
import { findingRoutes } from "../../modules/findings/findings.routes.js";
import { projectRoutes } from "../../modules/projects/projects.routes.js";
import { apiKeyRoutes } from "../../modules/api-keys/api-keys.routes.js";
import { subscriptionRoutes } from "../../modules/subscriptions/subscriptions.routes.js";

export const v1Router = Router();

v1Router.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    version: "v1",
    timestamp: new Date().toISOString()
  });
});

v1Router.use("/auth", authRoutes);
v1Router.use("/organizations/:organizationId/api-keys", apiKeyRoutes);
v1Router.use("/organizations/:organizationId/subscriptions", subscriptionRoutes);
v1Router.use("/organizations", organizationRoutes);
v1Router.use("/scans", scanRoutes);
v1Router.use("/reports", reportRoutes);
v1Router.use("/findings", findingRoutes);
v1Router.use("/projects", projectRoutes);
v1Router.use("/vulnerabilities", vulnerabilityRoutes);
