import { Router } from "express";
import { authenticateJwtOrApiKey } from "../../common/middleware/api-key-auth.middleware.js";
import { requireOrganizationParam, requirePermissions } from "../../common/middleware/authorize.middleware.js";
import { asyncHandler } from "../../common/middleware/async-handler.js";
import { validateRequest } from "../../common/validation/validate-request.js";
import { organizationEvidenceQuery, findingParams } from "./findings.schemas.js";
import { FindingsController } from "./findings.controller.js";
import { ReviewController } from "../review/review.controller.js";
import {
  findingAssignmentBody,
  findingCommentBody,
  reviewOrganizationQuery,
  reviewStatusBody,
  suppressFindingBody,
  unsuppressFindingBody
} from "../review/review.schemas.js";

const controller = new FindingsController();
const reviewController = new ReviewController();

export const findingRoutes = Router();

findingRoutes.use(authenticateJwtOrApiKey);

findingRoutes.get(
  "/:findingId",
  validateRequest({ params: findingParams, query: organizationEvidenceQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(controller.get)
);

findingRoutes.get(
  "/:findingId/evidence",
  validateRequest({ params: findingParams, query: organizationEvidenceQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(controller.evidence)
);

findingRoutes.get(
  "/:findingId/review",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(reviewController.getReview)
);

findingRoutes.post(
  "/:findingId/review/status",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery, body: reviewStatusBody }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:update"),
  asyncHandler(reviewController.changeStatus)
);

findingRoutes.post(
  "/:findingId/comments",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery, body: findingCommentBody }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:update"),
  asyncHandler(reviewController.addComment)
);

findingRoutes.post(
  "/:findingId/assign",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery, body: findingAssignmentBody }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:update"),
  asyncHandler(reviewController.assign)
);

findingRoutes.post(
  "/:findingId/suppress",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery, body: suppressFindingBody }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:update"),
  asyncHandler(reviewController.suppress)
);

findingRoutes.post(
  "/:findingId/unsuppress",
  validateRequest({ params: findingParams, query: reviewOrganizationQuery, body: unsuppressFindingBody }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:update"),
  asyncHandler(reviewController.unsuppress)
);
