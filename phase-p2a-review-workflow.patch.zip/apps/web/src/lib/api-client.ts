import type {
  ApiKeyRecord,
  AuditReport,
  BaselineComparison,
  CodeOwnerRule,
  EvidenceSummary,
  FindingEvidence,
  FindingReview,
  FindingReviewStatus,
  FindingSuppressionRule,
  CreatedApiKey,
  Organization,
  ReviewSummary,
  Scan,
  Vulnerability
} from "@/types/api";

export interface WorkspaceConfig {
  apiBaseUrl: string;
  realtimeWsUrl: string;
  accessToken: string;
  organizationId: string;
}

export const defaultApiBaseUrl =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:4000/api/v1";

export const defaultRealtimeWsUrl =
  process.env.NEXT_PUBLIC_REALTIME_WS_URL ?? "ws://localhost:4000/api/v1/realtime";

export class AuditScannerApiClient {
  constructor(private readonly config: WorkspaceConfig) {}

  listScans(limit = 20): Promise<Scan[]> {
    return this.request(`/scans?organizationId=${this.config.organizationId}&limit=${limit}`);
  }

  getScan(scanId: string): Promise<Scan> {
    return this.request(`/scans/${scanId}?organizationId=${this.config.organizationId}`);
  }

  listScanFindings(scanId: string, limit = 100): Promise<Vulnerability[]> {
    return this.request(`/scans/${scanId}/findings?organizationId=${this.config.organizationId}&limit=${limit}`);
  }

  getEvidenceSummary(scanId: string): Promise<EvidenceSummary> {
    return this.request(`/scans/${scanId}/evidence-summary?organizationId=${this.config.organizationId}`);
  }

  getFinding(findingId: string): Promise<Vulnerability> {
    return this.request(`/findings/${findingId}?organizationId=${this.config.organizationId}`);
  }

  getFindingEvidence(findingId: string): Promise<FindingEvidence[]> {
    return this.request(`/findings/${findingId}/evidence?organizationId=${this.config.organizationId}`);
  }

  createScan(input: {
    title?: string;
    priority: "LOW" | "NORMAL" | "HIGH" | "CRITICAL";
    target: {
      type: "ADDRESS" | "SOURCE" | "REPOSITORY" | "BYTECODE";
      chainId?: string;
      address?: string;
      repositoryUrl?: string;
      artifactKey?: string;
    };
    analyzers: Array<"slither" | "mythril" | "semgrep" | "foundry">;
    projectId?: string;
  }): Promise<Scan> {
    return this.request("/scans", {
      method: "POST",
      body: JSON.stringify({
        organizationId: this.config.organizationId,
        ...input
      })
    });
  }

  cancelScan(scanId: string): Promise<Scan> {
    return this.request(`/scans/${scanId}/cancel?organizationId=${this.config.organizationId}`, {
      method: "POST"
    });
  }

  listVulnerabilities(input: { limit?: number; scanId?: string } = {}): Promise<Vulnerability[]> {
    const params = new URLSearchParams({
      organizationId: this.config.organizationId,
      limit: String(input.limit ?? 100)
    });
    if (input.scanId) {
      params.set("scanId", input.scanId);
    }
    return this.request(`/vulnerabilities?${params.toString()}`);
  }

  listReports(limit = 20): Promise<AuditReport[]> {
    return this.request(`/reports?organizationId=${this.config.organizationId}&limit=${limit}`);
  }

  getReport(reportId: string): Promise<AuditReport> {
    return this.request(`/reports/${reportId}?organizationId=${this.config.organizationId}`);
  }

  getReviewSummary(scanId: string): Promise<ReviewSummary> {
    return this.request(`/scans/${scanId}/review-summary?organizationId=${this.config.organizationId}`);
  }

  getBaselineComparison(scanId: string, baseScanId?: string): Promise<BaselineComparison> {
    const params = new URLSearchParams({ organizationId: this.config.organizationId });
    if (baseScanId) params.set("baseScanId", baseScanId);
    return this.request(`/scans/${scanId}/baseline-comparison?${params.toString()}`);
  }

  getFindingReview(findingId: string): Promise<{ findingId: string; review: FindingReview | null; effectiveStatus: FindingReviewStatus }> {
    return this.request(`/findings/${findingId}/review?organizationId=${this.config.organizationId}`);
  }

  updateFindingReviewStatus(
    findingId: string,
    input: { status: FindingReviewStatus; reason?: string }
  ): Promise<FindingReview> {
    return this.request(`/findings/${findingId}/review/status?organizationId=${this.config.organizationId}`, {
      method: "POST",
      body: JSON.stringify(input)
    });
  }

  addFindingComment(findingId: string, body: string): Promise<unknown> {
    return this.request(`/findings/${findingId}/comments?organizationId=${this.config.organizationId}`, {
      method: "POST",
      body: JSON.stringify({ body })
    });
  }

  assignFinding(
    findingId: string,
    input: { assigneeName?: string; assigneeEmail?: string; assigneeTeam?: string; reason?: string }
  ): Promise<FindingReview> {
    return this.request(`/findings/${findingId}/assign?organizationId=${this.config.organizationId}`, {
      method: "POST",
      body: JSON.stringify(input)
    });
  }

  suppressFinding(findingId: string, reason: string): Promise<FindingReview> {
    return this.request(`/findings/${findingId}/suppress?organizationId=${this.config.organizationId}`, {
      method: "POST",
      body: JSON.stringify({ reason })
    });
  }

  unsuppressFinding(findingId: string, reason?: string): Promise<FindingReview> {
    return this.request(`/findings/${findingId}/unsuppress?organizationId=${this.config.organizationId}`, {
      method: "POST",
      body: JSON.stringify({ reason })
    });
  }

  listSuppressionRules(projectId: string): Promise<FindingSuppressionRule[]> {
    return this.request(`/projects/${projectId}/suppression-rules?organizationId=${this.config.organizationId}`);
  }

  listCodeOwners(projectId: string): Promise<CodeOwnerRule[]> {
    return this.request(`/projects/${projectId}/codeowners?organizationId=${this.config.organizationId}`);
  }

  exportSarif(scanId: string, includeSuppressed = false): Promise<unknown> {
    return this.request(
      `/scans/${scanId}/export/sarif?organizationId=${this.config.organizationId}&includeSuppressed=${includeSuppressed}`
    );
  }

  getOrganization(): Promise<Organization> {
    return this.request(`/organizations/${this.config.organizationId}`);
  }

  updateOrganization(input: Partial<Pick<Organization, "name" | "billingEmail" | "status">>): Promise<Organization> {
    return this.request(`/organizations/${this.config.organizationId}`, {
      method: "PATCH",
      body: JSON.stringify(input)
    });
  }

  listApiKeys(): Promise<ApiKeyRecord[]> {
    return this.request(`/organizations/${this.config.organizationId}/api-keys`);
  }

  createApiKey(input: { name: string; scopes: string[]; expiresAt?: string }): Promise<CreatedApiKey> {
    return this.request(`/organizations/${this.config.organizationId}/api-keys`, {
      method: "POST",
      body: JSON.stringify(input)
    });
  }

  revokeApiKey(apiKeyId: string): Promise<{ ok: true }> {
    return this.request(`/organizations/${this.config.organizationId}/api-keys/${apiKeyId}`, {
      method: "DELETE"
    });
  }

  private async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const response = await fetch(`${this.config.apiBaseUrl}${path}`, {
      ...init,
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${this.config.accessToken}`,
        ...init.headers
      },
      cache: "no-store"
    });

    if (!response.ok) {
      let message = `Request failed with status ${response.status}`;
      try {
        const payload = (await response.json()) as { error?: { message?: string } };
        message = payload.error?.message ?? message;
      } catch {
        // Keep the HTTP status message.
      }
      throw new Error(message);
    }

    return (await response.json()) as T;
  }
}

export function hasWorkspaceConfig(config: WorkspaceConfig): boolean {
  return Boolean(config.apiBaseUrl && config.realtimeWsUrl && config.accessToken && config.organizationId);
}
