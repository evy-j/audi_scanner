"use client";

import * as React from "react";
import { Download, FileText, ShieldAlert, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AuditScannerApiClient, hasWorkspaceConfig } from "@/lib/api-client";
import { useWorkspaceConfig } from "@/hooks/use-workspace-config";
import { formatDateTime, toNumber } from "@/lib/utils";
import type {
  AuditReport,
  BaselineComparison,
  EvidenceSummary,
  FindingReviewStatus,
  ReviewSummary,
  Scan,
  Severity,
  Vulnerability
} from "@/types/api";

export function ReportViewer({ reportId }: { reportId: string }) {
  const { config } = useWorkspaceConfig();
  const [report, setReport] = React.useState<AuditReport | null>(null);
  const [reports, setReports] = React.useState<AuditReport[]>([]);
  const [vulnerabilities, setVulnerabilities] = React.useState<Vulnerability[]>([]);
  const [scan, setScan] = React.useState<Scan | null>(null);
  const [evidenceSummary, setEvidenceSummary] = React.useState<EvidenceSummary | null>(null);
  const [reviewSummary, setReviewSummary] = React.useState<ReviewSummary | null>(null);
  const [baselineComparison, setBaselineComparison] = React.useState<BaselineComparison | null>(null);
  const [selectedFinding, setSelectedFinding] = React.useState<Vulnerability | null>(null);
  const [reviewStatusFilter, setReviewStatusFilter] = React.useState<"ALL" | FindingReviewStatus>("ALL");
  const [severityFilter, setSeverityFilter] = React.useState<"ALL" | Severity>("ALL");
  const [confidenceFilter, setConfidenceFilter] = React.useState("ALL");
  const [analyzerFilter, setAnalyzerFilter] = React.useState("ALL");
  const [reviewActionError, setReviewActionError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!hasWorkspaceConfig(config)) {
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const client = new AuditScannerApiClient(config);
        let selectedReport: AuditReport | null = null;
        if (reportId === "latest") {
          const list = await client.listReports(10);
          setReports(list);
          selectedReport = list[0] ?? null;
        } else {
          selectedReport = await client.getReport(reportId);
        }
        setReport(selectedReport);
        if (selectedReport) {
          const [scanRecord, findings, summary] = await Promise.all([
            client.getScan(selectedReport.scanId),
            client.listScanFindings(selectedReport.scanId, 100),
            client.getEvidenceSummary(selectedReport.scanId)
          ]);
          const [reviewSummaryResult, baselineResult] = await Promise.allSettled([
            client.getReviewSummary(selectedReport.scanId),
            client.getBaselineComparison(selectedReport.scanId)
          ]);
          setScan(scanRecord);
          setVulnerabilities(findings);
          setEvidenceSummary(summary);
          setReviewSummary(reviewSummaryResult.status === "fulfilled" ? reviewSummaryResult.value : null);
          setBaselineComparison(baselineResult.status === "fulfilled" ? baselineResult.value : null);
          setSelectedFinding((current) =>
            current ? findings.find((finding) => finding.id === current.id) ?? null : findings[0] ?? null
          );
        } else {
          setScan(null);
          setVulnerabilities([]);
          setEvidenceSummary(null);
          setReviewSummary(null);
          setBaselineComparison(null);
          setSelectedFinding(null);
        }
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Unable to load report");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [config, reportId]);

  const filteredVulnerabilities = vulnerabilities.filter((finding) => {
    const reviewStatus = finding.review?.status ?? "UNREVIEWED";
    return (
      (reviewStatusFilter === "ALL" || reviewStatus === reviewStatusFilter) &&
      (severityFilter === "ALL" || finding.severity === severityFilter) &&
      (confidenceFilter === "ALL" || finding.confidence === confidenceFilter) &&
      (analyzerFilter === "ALL" || finding.analyzer === analyzerFilter)
    );
  });

  const refreshFinding = React.useCallback(
    async (findingId: string) => {
      if (!hasWorkspaceConfig(config)) return;
      const client = new AuditScannerApiClient(config);
      const updated = await client.getFinding(findingId);
      setVulnerabilities((items) => items.map((item) => (item.id === findingId ? updated : item)));
      setSelectedFinding(updated);
      if (updated.scanId) {
        const [summaryResult, baselineResult] = await Promise.allSettled([
          client.getReviewSummary(updated.scanId),
          client.getBaselineComparison(updated.scanId)
        ]);
        if (summaryResult.status === "fulfilled") setReviewSummary(summaryResult.value);
        if (baselineResult.status === "fulfilled") setBaselineComparison(baselineResult.value);
      }
    },
    [config]
  );

  const exportSarif = async () => {
    if (!hasWorkspaceConfig(config) || !scan) return;
    setReviewActionError(null);
    try {
      const sarif = await new AuditScannerApiClient(config).exportSarif(scan.id, true);
      const blob = new Blob([JSON.stringify(sarif, null, 2)], { type: "application/sarif+json" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${scan.id}.sarif`;
      anchor.click();
      URL.revokeObjectURL(url);
    } catch (cause) {
      setReviewActionError(cause instanceof Error ? cause.message : "Unable to export SARIF");
    }
  };

  return (
    <AppShell>
      <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <Badge variant="blue" className="mb-3">Audit reports</Badge>
          <h1 className="text-3xl font-semibold tracking-tight text-white">Report intelligence</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
            Executive findings, risk scoring, remediation guidance, and PDF export metadata.
          </p>
        </div>
        <Button variant="secondary" disabled={!report?.pdfStorageKey}>
          <Download className="h-4 w-4" />
          PDF artifact
        </Button>
        <Button variant="secondary" disabled={!scan} onClick={exportSarif}>
          <Download className="h-4 w-4" />
          SARIF
        </Button>
      </div>

      {error ? <div className="mb-4 rounded-md border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-100">{error}</div> : null}
      {reviewActionError ? <div className="mb-4 rounded-md border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-100">{reviewActionError}</div> : null}

      {loading ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Skeleton className="h-[520px]" />
          <Skeleton className="h-[320px]" />
        </div>
      ) : report ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle>{report.title}</CardTitle>
                  <p className="mt-2 text-sm text-muted-foreground">{report.reportNumber ?? report.id}</p>
                </div>
                <Badge variant={toNumber(report.riskScore) >= 70 ? "red" : "default"}>{report.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6 grid gap-3 sm:grid-cols-3">
                <Stat label="Risk score" value={toNumber(report.riskScore).toFixed(0)} />
                <Stat label="Version" value={`v${report.version}`} />
                <Stat label="Generated" value={formatDateTime(report.generatedAt)} />
              </div>
              <section className="rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Executive summary
                </div>
                <p className="text-sm leading-7 text-slate-300">
                  {report.executiveSummary ?? "The report record does not include an executive summary."}
                </p>
              </section>
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-amber-200" />
                  Evidence-backed findings
                </div>
                <FindingFilters
                  reviewStatusFilter={reviewStatusFilter}
                  setReviewStatusFilter={setReviewStatusFilter}
                  severityFilter={severityFilter}
                  setSeverityFilter={setSeverityFilter}
                  confidenceFilter={confidenceFilter}
                  setConfidenceFilter={setConfidenceFilter}
                  analyzerFilter={analyzerFilter}
                  setAnalyzerFilter={setAnalyzerFilter}
                  vulnerabilities={vulnerabilities}
                />
                {filteredVulnerabilities.length > 0 ? (
                  <div className="space-y-5">
                    {severityOrder.map((severity) => {
                      const items = filteredVulnerabilities.filter((finding) => finding.severity === severity);
                      if (items.length === 0) return null;
                      return (
                        <div key={severity}>
                          <div className="mb-2 flex items-center gap-2">
                            <Badge variant={severity === "CRITICAL" || severity === "HIGH" ? "red" : "default"}>
                              {severity}
                            </Badge>
                            <span className="text-xs text-muted-foreground">{items.length} persisted</span>
                          </div>
                          <div className="space-y-3">
                            {items.map((finding) => (
                              <FindingCard
                                key={finding.id}
                                finding={finding}
                                selected={selectedFinding?.id === finding.id}
                                onSelect={() => {
                                  setSelectedFinding(finding);
                                  void refreshFinding(finding.id);
                                }}
                              />
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">No persisted findings match the selected filters.</div>
                )}
              </section>
              {baselineComparison ? (
                <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                  <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                    <ShieldAlert className="h-4 w-4 text-sky-200" />
                    Baseline comparison
                  </div>
                  <div className="grid gap-2 sm:grid-cols-5">
                    <MiniStat label="New" value={String(baselineComparison.newFindings.length)} />
                    <MiniStat label="Existing" value={String(baselineComparison.existingFindings.length)} />
                    <MiniStat label="Fixed" value={String(baselineComparison.fixedFindings.length)} />
                    <MiniStat label="Regressed" value={String(baselineComparison.regressedFindings.length)} />
                    <MiniStat label="Suppressed" value={String(baselineComparison.suppressedFindings.length)} />
                  </div>
                </section>
              ) : null}
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <FileText className="h-4 w-4 text-sky-200" />
                  Artifacts
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div>Markdown: {report.storageKey ?? "Not available"}</div>
                  <div>PDF: {report.pdfStorageKey ?? "Not available"}</div>
                  <div>Checksum: {report.checksumSha256 ?? "Not available"}</div>
                </div>
              </section>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Analyzer status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {scan?.analyzerRuns?.length ? (
                scan.analyzerRuns.map((run) => (
                  <div key={run.id} className="rounded-md border border-white/10 bg-white/6 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-medium text-white">{run.toolName}</div>
                      <Badge variant={run.status === "COMPLETED" ? "default" : "red"}>
                        {run.status === "COMPLETED" ? "Assessed" : "Not Assessed"}
                      </Badge>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">Raw status: {run.status}</div>
                    {run.error ? <div className="mt-2 text-xs leading-5 text-red-100">{run.error}</div> : null}
                  </div>
                ))
              ) : (
                <div className="rounded-md border border-white/10 bg-white/6 p-3 text-sm text-muted-foreground">
                  Analyzer runs are not available for this scan.
                </div>
              )}
              {evidenceSummary ? (
                <div className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="mb-2 flex items-center gap-2 text-sm font-medium text-white">
                    <ShieldAlert className="h-4 w-4 text-amber-200" />
                    Evidence summary
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div>Findings: {evidenceSummary.findingCount}</div>
                    <div>Evidence items: {evidenceSummary.evidenceCount}</div>
                    <div>Max exploitability: {evidenceSummary.maxExploitabilityScore.toFixed(0)}</div>
                    <div>Average evidence quality: {evidenceSummary.averageEvidenceQuality.toFixed(0)}</div>
                  </div>
                </div>
              ) : null}
              {reviewSummary ? (
                <div className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="mb-2 text-sm font-medium text-white">Review summary</div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div>Reviewed: {reviewSummary.findingCount - (reviewSummary.statusCounts.UNREVIEWED ?? 0)}</div>
                    <div>Needs review: {reviewSummary.statusCounts.NEEDS_REVIEW ?? 0}</div>
                    <div>Suppressed: {reviewSummary.suppressedCount}</div>
                  </div>
                </div>
              ) : null}
              {selectedFinding ? (
                <ReviewPanel
                  finding={selectedFinding}
                  configReady={hasWorkspaceConfig(config)}
                  onError={setReviewActionError}
                  onRefresh={refreshFinding}
                  clientFactory={() => new AuditScannerApiClient(config)}
                />
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(reports.length > 0 ? reports : [report]).map((item) => (
                <div key={item.id} className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="text-sm font-medium text-white">{item.title}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{formatDateTime(item.createdAt)}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="p-10 text-center text-sm text-muted-foreground">No report available</CardContent>
        </Card>
      )}
    </AppShell>
  );
}

const severityOrder = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"] as const;

function FindingCard({
  finding,
  selected,
  onSelect
}: {
  finding: Vulnerability;
  selected: boolean;
  onSelect: () => void;
}) {
  const evidence = finding.evidenceItems ?? [];
  const state = finding.confidenceState ?? "CANDIDATE";
  const reviewStatus = finding.review?.status ?? "UNREVIEWED";

  return (
    <div className={`rounded-md border p-3 ${selected ? "border-primary/60 bg-primary/10" : "border-white/10 bg-black/20"}`}>
      <div className="flex items-start justify-between gap-3">
        <button type="button" onClick={onSelect} className="min-w-0 text-left">
          <div className="text-sm font-medium text-white">{finding.title}</div>
          <div className="mt-1 text-xs text-muted-foreground">
            {finding.filePath ?? "Unknown file"}
            {finding.lineStart ? `:${finding.lineStart}` : ""}
            {finding.lineEnd && finding.lineEnd !== finding.lineStart ? `-${finding.lineEnd}` : ""}
          </div>
        </button>
        <div className="flex flex-wrap justify-end gap-2">
          <Badge variant={reviewStatus === "SUPPRESSED" ? "red" : "blue"}>{reviewStatus}</Badge>
          <Badge variant={state === "SUPPORTED" ? "default" : "blue"}>{state}</Badge>
          <Badge variant={finding.severity === "CRITICAL" || finding.severity === "HIGH" ? "red" : "default"}>
            {finding.severity}
          </Badge>
        </div>
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <MiniStat label="Confidence" value={scoreValue(finding.confidenceScore)} />
        <MiniStat label="Exploitability" value={scoreValue(finding.exploitabilityScore)} />
        <MiniStat label="Priority" value={scoreValue(finding.priorityScore)} />
      </div>
      {finding.remediation ? (
        <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted-foreground">{finding.remediation}</p>
      ) : null}
      <details className="mt-3 rounded-md border border-white/10 bg-white/5 p-3">
        <summary className="cursor-pointer text-xs font-medium text-white">Evidence drawer</summary>
        <div className="mt-3 space-y-3">
          {evidence.length > 0 ? (
            evidence.map((item) => (
              <div key={item.id} className="rounded border border-white/10 bg-black/20 p-3">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <Badge variant="blue">{item.evidenceType}</Badge>
                  <span className="text-muted-foreground">
                    {item.analyzerRun?.toolName ?? item.detectorName ?? "Analyzer"}
                  </span>
                  <span className="text-muted-foreground">{item.ruleId ?? "No rule id"}</span>
                </div>
                <div className="mt-2 text-xs leading-5 text-slate-300">
                  {item.filePath ?? "Unknown file"}
                  {item.startLine ? `:${item.startLine}` : ""}
                  {item.endLine && item.endLine !== item.startLine ? `-${item.endLine}` : ""}
                </div>
                {item.message ? <p className="mt-2 text-xs leading-5 text-muted-foreground">{item.message}</p> : null}
                {item.snippet ? (
                  <pre className="mt-2 max-h-48 overflow-auto rounded bg-black/40 p-3 text-xs leading-5 text-slate-200">
                    {item.snippet}
                  </pre>
                ) : (
                  <div className="mt-2 text-xs text-amber-100">Source range or snippet quality is limited.</div>
                )}
                <div className="mt-2 text-[11px] text-muted-foreground">
                  Raw artifact: {item.rawArtifactPath ?? "Not available"}
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-muted-foreground">No evidence rows persisted for this finding.</div>
          )}
        </div>
      </details>
    </div>
  );
}

function FindingFilters({
  reviewStatusFilter,
  setReviewStatusFilter,
  severityFilter,
  setSeverityFilter,
  confidenceFilter,
  setConfidenceFilter,
  analyzerFilter,
  setAnalyzerFilter,
  vulnerabilities
}: {
  reviewStatusFilter: "ALL" | FindingReviewStatus;
  setReviewStatusFilter: (value: "ALL" | FindingReviewStatus) => void;
  severityFilter: "ALL" | Severity;
  setSeverityFilter: (value: "ALL" | Severity) => void;
  confidenceFilter: string;
  setConfidenceFilter: (value: string) => void;
  analyzerFilter: string;
  setAnalyzerFilter: (value: string) => void;
  vulnerabilities: Vulnerability[];
}) {
  const analyzers = Array.from(new Set(vulnerabilities.map((finding) => finding.analyzer))).sort();
  const confidences = Array.from(new Set(vulnerabilities.map((finding) => finding.confidence))).sort();

  return (
    <div className="mb-4 grid gap-2 md:grid-cols-4">
      <SelectFilter
        label="Review"
        value={reviewStatusFilter}
        onChange={(value) => setReviewStatusFilter(value as "ALL" | FindingReviewStatus)}
        options={["ALL", ...reviewStatuses]}
      />
      <SelectFilter
        label="Severity"
        value={severityFilter}
        onChange={(value) => setSeverityFilter(value as "ALL" | Severity)}
        options={["ALL", ...severityOrder]}
      />
      <SelectFilter
        label="Confidence"
        value={confidenceFilter}
        onChange={setConfidenceFilter}
        options={["ALL", ...confidences]}
      />
      <SelectFilter
        label="Analyzer"
        value={analyzerFilter}
        onChange={setAnalyzerFilter}
        options={["ALL", ...analyzers]}
      />
    </div>
  );
}

function ReviewPanel({
  finding,
  configReady,
  onError,
  onRefresh,
  clientFactory
}: {
  finding: Vulnerability;
  configReady: boolean;
  onError: (message: string | null) => void;
  onRefresh: (findingId: string) => Promise<void>;
  clientFactory: () => AuditScannerApiClient;
}) {
  const [status, setStatus] = React.useState<FindingReviewStatus>(finding.review?.status ?? "UNREVIEWED");
  const [reason, setReason] = React.useState("");
  const [comment, setComment] = React.useState("");
  const [assignee, setAssignee] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    setStatus(finding.review?.status ?? "UNREVIEWED");
    setReason("");
    setComment("");
    setAssignee(finding.review?.assignedToEmail ?? finding.review?.assignedToName ?? "");
  }, [finding.id, finding.review]);

  const run = async (operation: (client: AuditScannerApiClient) => Promise<unknown>) => {
    if (!configReady) return;
    setBusy(true);
    onError(null);
    try {
      await operation(clientFactory());
      await onRefresh(finding.id);
    } catch (cause) {
      onError(cause instanceof Error ? cause.message : "Review action failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-md border border-white/10 bg-white/6 p-3">
      <div className="mb-2 text-sm font-medium text-white">Finding review</div>
      <div className="mb-3 text-xs leading-5 text-muted-foreground">{finding.title}</div>
      <div className="space-y-2">
        <SelectFilter
          label="Status"
          value={status}
          onChange={(value) => setStatus(value as FindingReviewStatus)}
          options={reviewStatuses}
        />
        <input
          value={reason}
          onChange={(event) => setReason(event.target.value)}
          placeholder="Reason"
          className="w-full rounded border border-white/10 bg-black/30 px-2 py-2 text-xs text-white outline-none"
        />
        <Button
          variant="secondary"
          disabled={busy}
          onClick={() =>
            run((client) =>
              client.updateFindingReviewStatus(finding.id, {
                status,
                ...(reason ? { reason } : {})
              })
            )
          }
        >
          Save status
        </Button>
        <textarea
          value={comment}
          onChange={(event) => setComment(event.target.value)}
          placeholder="Comment"
          className="min-h-20 w-full rounded border border-white/10 bg-black/30 px-2 py-2 text-xs text-white outline-none"
        />
        <Button
          variant="secondary"
          disabled={busy || !comment.trim()}
          onClick={() => run((client) => client.addFindingComment(finding.id, comment.trim()))}
        >
          Add comment
        </Button>
        <input
          value={assignee}
          onChange={(event) => setAssignee(event.target.value)}
          placeholder="Owner email or name"
          className="w-full rounded border border-white/10 bg-black/30 px-2 py-2 text-xs text-white outline-none"
        />
        <Button
          variant="secondary"
          disabled={busy || !assignee.trim()}
          onClick={() =>
            run((client) =>
              assignee.includes("@")
                ? client.assignFinding(finding.id, {
                    assigneeEmail: assignee.trim(),
                    ...(reason ? { reason } : {})
                  })
                : client.assignFinding(finding.id, {
                    assigneeName: assignee.trim(),
                    ...(reason ? { reason } : {})
                  })
            )
          }
        >
          Assign
        </Button>
        {finding.review?.status === "SUPPRESSED" ? (
          <Button variant="secondary" disabled={busy} onClick={() => run((client) => client.unsuppressFinding(finding.id, reason || undefined))}>
            Unsuppress
          </Button>
        ) : (
          <Button variant="secondary" disabled={busy || !reason.trim()} onClick={() => run((client) => client.suppressFinding(finding.id, reason.trim()))}>
            Suppress
          </Button>
        )}
      </div>
      <div className="mt-4 border-t border-white/10 pt-3">
        <div className="mb-2 text-xs font-medium text-white">Audit trail</div>
        <div className="space-y-2">
          {finding.review?.events?.length ? (
            finding.review.events.map((event) => (
              <div key={event.id} className="rounded border border-white/10 bg-black/20 p-2 text-xs">
                <div className="flex items-center justify-between gap-2 text-white">
                  <span>{event.action}</span>
                  <span className="text-muted-foreground">{formatDateTime(event.createdAt)}</span>
                </div>
                <div className="mt-1 text-muted-foreground">Actor: {event.actorUserId ?? "API key/system"}</div>
                <div className="mt-1 text-muted-foreground">Previous: {formatJson(event.previousValue)}</div>
                <div className="mt-1 text-muted-foreground">New: {formatJson(event.newValue)}</div>
                {event.reason ? <div className="mt-1 text-slate-300">{event.reason}</div> : null}
              </div>
            ))
          ) : (
            <div className="text-xs text-muted-foreground">No review events persisted yet.</div>
          )}
        </div>
      </div>
    </div>
  );
}

function SelectFilter({
  label,
  value,
  onChange,
  options
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: readonly string[];
}) {
  return (
    <label className="block text-xs text-muted-foreground">
      {label}
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 w-full rounded border border-white/10 bg-black/30 px-2 py-2 text-xs text-white outline-none"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}

const reviewStatuses: FindingReviewStatus[] = [
  "UNREVIEWED",
  "NEEDS_REVIEW",
  "ACCEPTED",
  "FALSE_POSITIVE",
  "RISK_ACCEPTED",
  "FIXED",
  "WONT_FIX",
  "DUPLICATE",
  "SUPPRESSED"
];

function formatJson(value: Record<string, unknown> | null | undefined): string {
  return value ? JSON.stringify(value) : "None";
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-white/10 bg-white/5 px-2 py-1">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="text-xs font-semibold text-white">{value}</div>
    </div>
  );
}

function scoreValue(value: number | string | undefined): string {
  return value === undefined ? "0" : toNumber(value).toFixed(0);
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-white/10 bg-white/6 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-semibold text-white">{value}</div>
    </div>
  );
}
