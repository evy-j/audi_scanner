# Phase P1 Evidence Engine + High-Signal Finding Model Summary

This patch finishes P1 only. It does not add fake findings, stub AI agents, exploit automation, or P2/P3 systems.

## Implemented

- Added an evidence-backed finding model in Prisma:
  - `FindingEvidence`
  - `SourceRange`
  - `AnalyzerEvidence`
  - `TraceEvidence`
  - `FindingDecision`
  - `DetectorMetadata`
- Added `FindingConfidenceState`:
  - `CANDIDATE`
  - `SUPPORTED`
  - `TRIAGED`
  - `SIMULATED`
  - `CONFIRMED`
  - `REJECTED`
  - `NOT_ASSESSED`
- Added deterministic scoring:
  - `severityScore`
  - `confidenceScore`
  - `exploitabilityScore`
  - `priorityScore`
  - `evidenceQuality`
- Updated Slither, Semgrep, Mythril, and Aderyn normalizers to emit real analyzer evidence from tool output.
- Added Mythril trace evidence only when a real `tx_sequence` exists.
- Added duplicate suppression by analyzer/rule/file/function/line/message before aggregation.
- Persisted evidence rows, source ranges, analyzer evidence, detector metadata, and scoring decisions during worker normalization.
- Kept no-source-range findings, but scores them as lower-quality candidate findings.
- Preserved P0 analyzer failure semantics:
  - `TOOL_NOT_INSTALLED`
  - `PROVIDER_NOT_CONFIGURED`
  - `TIMEOUT`
  - `FAILED`
  - `NOT_ASSESSED`
  - `CANCELED`
- Added findings/evidence API endpoints returning repository-backed persisted data only:
  - `GET /api/v1/scans/:scanId/findings`
  - `GET /api/v1/findings/:findingId`
  - `GET /api/v1/findings/:findingId/evidence`
  - `GET /api/v1/scans/:scanId/evidence-summary`
- Updated the frontend report viewer to read persisted findings and evidence from the API:
  - severity grouping
  - confidence state
  - exploitability, confidence, and priority scores
  - evidence drawer
  - file path and line range
  - analyzer source/status
  - raw artifact references
  - Not Assessed display for missing/failed analyzer runs

## Database Changes

New Prisma migration:

```text
packages/database/prisma/migrations/20260523170000_p1_evidence_engine/migration.sql
```

The migration adds evidence tables, finding decision history, detector metadata, confidence-state enums, evidence-type enums, and score columns on persisted vulnerabilities.

## Tests Added

- Normalizer creates evidence from real Semgrep output.
- Duplicate analyzer messages are suppressed before aggregation.
- No-source-range findings are retained as lower-quality evidence.
- Missing assessed evidence scores as `NOT_ASSESSED`.
- Deterministic scoring remains stable.
- Worker persistence writes vulnerability, source range, evidence, analyzer evidence, detector metadata, and decision rows.
- Findings API endpoints return persisted repository data.

## Verification Completed

```bash
npm run db:generate
npm run typecheck
npm test
npm run build
```

`npm run db:generate` required elevated filesystem access on Windows because Prisma probes `C:\Users\nk148` outside the workspace. The rerun succeeded.

## Commands

Install dependencies:

```bash
npm install
```

Generate Prisma client:

```bash
npm run db:generate
```

Run database migration in local development:

```bash
npm run db:migrate:dev
```

Deploy database migration in staging/production:

```bash
npm run db:deploy
```

Run API:

```bash
npm run dev:api
```

Run worker:

```bash
npm run dev:worker
```

Run web:

```bash
npm run dev:web
```

Run typecheck:

```bash
npm run typecheck
```

Run tests:

```bash
npm test
```

Build:

```bash
npm run build
```

## Limitations

- P1 does not mark findings `SIMULATED` or `CONFIRMED`; those states require real simulation/proof in a later phase.
- P1 scoring is deterministic only. No AI scoring or autonomous triage is included.
- Trace evidence is stored only when analyzers provide real trace data.
- Aderyn normalization is implemented for real Aderyn-shaped JSON artifacts, but no new scanner execution adapter is added in P1.

## Recommended P2

Implement an evidence review workflow: reviewer triage actions, suppression rules with audit trails, baseline comparisons, code-owner routing, and SARIF export/import. This should build on P1 evidence rows rather than adding new finding sources.
