import { describe, expect, it } from "vitest";
import { promises as fs } from "node:fs";

describe("Prisma schema contract", () => {
  it("declares the scan persistence models", async () => {
    const schema = await fs.readFile("packages/database/prisma/schema.prisma", "utf8");

    expect(schema).toContain("model Scan ");
    expect(schema).toContain("model ScanTarget ");
    expect(schema).toContain("model Vulnerability ");
    expect(schema).toContain("model AuditReport ");
    expect(schema).toContain("@@index([status, priority, queuedAt])");
    expect(schema).toContain("enum FindingConfidenceState");
    expect(schema).toContain("model FindingEvidence ");
    expect(schema).toContain("model SourceRange ");
    expect(schema).toContain("model AnalyzerEvidence ");
    expect(schema).toContain("model FindingDecision ");
    expect(schema).toContain("model DetectorMetadata ");
  });
});
