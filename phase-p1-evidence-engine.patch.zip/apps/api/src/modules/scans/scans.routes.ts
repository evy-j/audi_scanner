import { Router } from "express";
import { authenticateJwtOrApiKey } from "../../common/middleware/api-key-auth.middleware.js";
import {
  requireOrganizationParam,
  requirePermissions
} from "../../common/middleware/authorize.middleware.js";
import { scanRateLimit } from "../../common/middleware/rate-limit.middleware.js";
import { validateRequest } from "../../common/validation/validate-request.js";
import { asyncHandler } from "../../common/middleware/async-handler.js";
import { auditLog } from "../../common/middleware/audit-log.middleware.js";
import {
  createScanSchema,
  listScansQuery,
  scanParams
} from "./scans.schemas.js";
import { organizationQuery } from "../../common/validation/common-schemas.js";
import { ScansController } from "./scans.controller.js";
import { FindingsController } from "../findings/findings.controller.js";
import { listScanFindingsQuery, scanFindingParams } from "../findings/findings.schemas.js";

const controller = new ScansController();
const findingsController = new FindingsController();

export const scanRoutes = Router();

scanRoutes.use(authenticateJwtOrApiKey);

scanRoutes.get(
  "/",
  validateRequest({ query: listScansQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:read"),
  asyncHandler(controller.list)
);

scanRoutes.post(
  "/",
  scanRateLimit,
  validateRequest({ body: createScanSchema }),
  requireOrganizationParam(),
  requirePermissions("scans:create"),
  auditLog("SCAN_START", "SCAN"),
  asyncHandler(controller.create)
);

scanRoutes.get(
  "/:scanId/findings",
  validateRequest({ params: scanFindingParams, query: listScanFindingsQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(findingsController.listByScan)
);

scanRoutes.get(
  "/:scanId/evidence-summary",
  validateRequest({ params: scanFindingParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(findingsController.evidenceSummary)
);

scanRoutes.get(
  "/:scanId",
  validateRequest({ params: scanParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:read"),
  asyncHandler(controller.get)
);

scanRoutes.post(
  "/:scanId/cancel",
  validateRequest({ params: scanParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:cancel"),
  auditLog("SCAN_CANCEL", "SCAN"),
  asyncHandler(controller.cancel)
);
