import { Router } from "express";
import { authenticateJwtOrApiKey } from "../../common/middleware/api-key-auth.middleware.js";
import { requireOrganizationParam, requirePermissions } from "../../common/middleware/authorize.middleware.js";
import { asyncHandler } from "../../common/middleware/async-handler.js";
import { validateRequest } from "../../common/validation/validate-request.js";
import { organizationEvidenceQuery, findingParams } from "./findings.schemas.js";
import { FindingsController } from "./findings.controller.js";

const controller = new FindingsController();

export const findingRoutes = Router();

findingRoutes.use(authenticateJwtOrApiKey);

findingRoutes.get(
  "/:findingId",
  validateRequest({ params: findingParams, query: organizationEvidenceQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(controller.get)
);

findingRoutes.get(
  "/:findingId/evidence",
  validateRequest({ params: findingParams, query: organizationEvidenceQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(controller.evidence)
);
