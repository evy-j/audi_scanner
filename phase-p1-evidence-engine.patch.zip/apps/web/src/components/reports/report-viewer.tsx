"use client";

import * as React from "react";
import { Download, FileText, ShieldAlert, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AuditScannerApiClient, hasWorkspaceConfig } from "@/lib/api-client";
import { useWorkspaceConfig } from "@/hooks/use-workspace-config";
import { formatDateTime, toNumber } from "@/lib/utils";
import type { AuditReport, EvidenceSummary, Scan, Vulnerability } from "@/types/api";

export function ReportViewer({ reportId }: { reportId: string }) {
  const { config } = useWorkspaceConfig();
  const [report, setReport] = React.useState<AuditReport | null>(null);
  const [reports, setReports] = React.useState<AuditReport[]>([]);
  const [vulnerabilities, setVulnerabilities] = React.useState<Vulnerability[]>([]);
  const [scan, setScan] = React.useState<Scan | null>(null);
  const [evidenceSummary, setEvidenceSummary] = React.useState<EvidenceSummary | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!hasWorkspaceConfig(config)) {
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const client = new AuditScannerApiClient(config);
        let selectedReport: AuditReport | null = null;
        if (reportId === "latest") {
          const list = await client.listReports(10);
          setReports(list);
          selectedReport = list[0] ?? null;
        } else {
          selectedReport = await client.getReport(reportId);
        }
        setReport(selectedReport);
        if (selectedReport) {
          const [scanRecord, findings, summary] = await Promise.all([
            client.getScan(selectedReport.scanId),
            client.listScanFindings(selectedReport.scanId, 100),
            client.getEvidenceSummary(selectedReport.scanId)
          ]);
          setScan(scanRecord);
          setVulnerabilities(findings);
          setEvidenceSummary(summary);
        } else {
          setScan(null);
          setVulnerabilities([]);
          setEvidenceSummary(null);
        }
      } catch (cause) {
        setError(cause instanceof Error ? cause.message : "Unable to load report");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [config, reportId]);

  return (
    <AppShell>
      <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <Badge variant="blue" className="mb-3">Audit reports</Badge>
          <h1 className="text-3xl font-semibold tracking-tight text-white">Report intelligence</h1>
          <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
            Executive findings, risk scoring, remediation guidance, and PDF export metadata.
          </p>
        </div>
        <Button variant="secondary" disabled={!report?.pdfStorageKey}>
          <Download className="h-4 w-4" />
          PDF artifact
        </Button>
      </div>

      {error ? <div className="mb-4 rounded-md border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-100">{error}</div> : null}

      {loading ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Skeleton className="h-[520px]" />
          <Skeleton className="h-[320px]" />
        </div>
      ) : report ? (
        <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle>{report.title}</CardTitle>
                  <p className="mt-2 text-sm text-muted-foreground">{report.reportNumber ?? report.id}</p>
                </div>
                <Badge variant={toNumber(report.riskScore) >= 70 ? "red" : "default"}>{report.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6 grid gap-3 sm:grid-cols-3">
                <Stat label="Risk score" value={toNumber(report.riskScore).toFixed(0)} />
                <Stat label="Version" value={`v${report.version}`} />
                <Stat label="Generated" value={formatDateTime(report.generatedAt)} />
              </div>
              <section className="rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-primary" />
                  Executive summary
                </div>
                <p className="text-sm leading-7 text-slate-300">
                  {report.executiveSummary ?? "The report record does not include an executive summary."}
                </p>
              </section>
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <ShieldCheck className="h-4 w-4 text-amber-200" />
                  Evidence-backed findings
                </div>
                {vulnerabilities.length > 0 ? (
                  <div className="space-y-5">
                    {severityOrder.map((severity) => {
                      const items = vulnerabilities.filter((finding) => finding.severity === severity);
                      if (items.length === 0) return null;
                      return (
                        <div key={severity}>
                          <div className="mb-2 flex items-center gap-2">
                            <Badge variant={severity === "CRITICAL" || severity === "HIGH" ? "red" : "default"}>
                              {severity}
                            </Badge>
                            <span className="text-xs text-muted-foreground">{items.length} persisted</span>
                          </div>
                          <div className="space-y-3">
                            {items.map((finding) => (
                              <FindingCard key={finding.id} finding={finding} />
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">No persisted findings for this report scan.</div>
                )}
              </section>
              <section className="mt-4 rounded-lg border border-white/10 bg-white/6 p-5">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <FileText className="h-4 w-4 text-sky-200" />
                  Artifacts
                </div>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <div>Markdown: {report.storageKey ?? "Not available"}</div>
                  <div>PDF: {report.pdfStorageKey ?? "Not available"}</div>
                  <div>Checksum: {report.checksumSha256 ?? "Not available"}</div>
                </div>
              </section>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Analyzer status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {scan?.analyzerRuns?.length ? (
                scan.analyzerRuns.map((run) => (
                  <div key={run.id} className="rounded-md border border-white/10 bg-white/6 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-sm font-medium text-white">{run.toolName}</div>
                      <Badge variant={run.status === "COMPLETED" ? "default" : "red"}>
                        {run.status === "COMPLETED" ? "Assessed" : "Not Assessed"}
                      </Badge>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">Raw status: {run.status}</div>
                    {run.error ? <div className="mt-2 text-xs leading-5 text-red-100">{run.error}</div> : null}
                  </div>
                ))
              ) : (
                <div className="rounded-md border border-white/10 bg-white/6 p-3 text-sm text-muted-foreground">
                  Analyzer runs are not available for this scan.
                </div>
              )}
              {evidenceSummary ? (
                <div className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="mb-2 flex items-center gap-2 text-sm font-medium text-white">
                    <ShieldAlert className="h-4 w-4 text-amber-200" />
                    Evidence summary
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div>Findings: {evidenceSummary.findingCount}</div>
                    <div>Evidence items: {evidenceSummary.evidenceCount}</div>
                    <div>Max exploitability: {evidenceSummary.maxExploitabilityScore.toFixed(0)}</div>
                    <div>Average evidence quality: {evidenceSummary.averageEvidenceQuality.toFixed(0)}</div>
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {(reports.length > 0 ? reports : [report]).map((item) => (
                <div key={item.id} className="rounded-md border border-white/10 bg-white/6 p-3">
                  <div className="text-sm font-medium text-white">{item.title}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{formatDateTime(item.createdAt)}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="p-10 text-center text-sm text-muted-foreground">No report available</CardContent>
        </Card>
      )}
    </AppShell>
  );
}

const severityOrder = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFORMATIONAL"] as const;

function FindingCard({ finding }: { finding: Vulnerability }) {
  const evidence = finding.evidenceItems ?? [];
  const state = finding.confidenceState ?? "CANDIDATE";

  return (
    <div className="rounded-md border border-white/10 bg-black/20 p-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-medium text-white">{finding.title}</div>
          <div className="mt-1 text-xs text-muted-foreground">
            {finding.filePath ?? "Unknown file"}
            {finding.lineStart ? `:${finding.lineStart}` : ""}
            {finding.lineEnd && finding.lineEnd !== finding.lineStart ? `-${finding.lineEnd}` : ""}
          </div>
        </div>
        <div className="flex flex-wrap justify-end gap-2">
          <Badge variant={state === "SUPPORTED" ? "default" : "blue"}>{state}</Badge>
          <Badge variant={finding.severity === "CRITICAL" || finding.severity === "HIGH" ? "red" : "default"}>
            {finding.severity}
          </Badge>
        </div>
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <MiniStat label="Confidence" value={scoreValue(finding.confidenceScore)} />
        <MiniStat label="Exploitability" value={scoreValue(finding.exploitabilityScore)} />
        <MiniStat label="Priority" value={scoreValue(finding.priorityScore)} />
      </div>
      {finding.remediation ? (
        <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted-foreground">{finding.remediation}</p>
      ) : null}
      <details className="mt-3 rounded-md border border-white/10 bg-white/5 p-3">
        <summary className="cursor-pointer text-xs font-medium text-white">Evidence drawer</summary>
        <div className="mt-3 space-y-3">
          {evidence.length > 0 ? (
            evidence.map((item) => (
              <div key={item.id} className="rounded border border-white/10 bg-black/20 p-3">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <Badge variant="blue">{item.evidenceType}</Badge>
                  <span className="text-muted-foreground">
                    {item.analyzerRun?.toolName ?? item.detectorName ?? "Analyzer"}
                  </span>
                  <span className="text-muted-foreground">{item.ruleId ?? "No rule id"}</span>
                </div>
                <div className="mt-2 text-xs leading-5 text-slate-300">
                  {item.filePath ?? "Unknown file"}
                  {item.startLine ? `:${item.startLine}` : ""}
                  {item.endLine && item.endLine !== item.startLine ? `-${item.endLine}` : ""}
                </div>
                {item.message ? <p className="mt-2 text-xs leading-5 text-muted-foreground">{item.message}</p> : null}
                {item.snippet ? (
                  <pre className="mt-2 max-h-48 overflow-auto rounded bg-black/40 p-3 text-xs leading-5 text-slate-200">
                    {item.snippet}
                  </pre>
                ) : (
                  <div className="mt-2 text-xs text-amber-100">Source range or snippet quality is limited.</div>
                )}
                <div className="mt-2 text-[11px] text-muted-foreground">
                  Raw artifact: {item.rawArtifactPath ?? "Not available"}
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-muted-foreground">No evidence rows persisted for this finding.</div>
          )}
        </div>
      </details>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded border border-white/10 bg-white/5 px-2 py-1">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="text-xs font-semibold text-white">{value}</div>
    </div>
  );
}

function scoreValue(value: number | string | undefined): string {
  return value === undefined ? "0" : toNumber(value).toFixed(0);
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-white/10 bg-white/6 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm font-semibold text-white">{value}</div>
    </div>
  );
}
