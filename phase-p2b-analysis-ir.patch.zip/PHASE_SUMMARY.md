# Phase P2B AST/CFG/Source-Map Deep Analysis Summary

This patch implements P2B only. It does not add AI agents, exploit simulation, remediation, fake findings, or automatic confirmation.

## Implemented

- Added `packages/analysis-ir` for real solc standard JSON extraction.
- Added Solidity file registry and source range normalization for solc `offset:length:fileIndex` ranges.
- Extracted persisted code intelligence when real compiler artifacts are available:
  - contracts
  - functions
  - modifiers
  - events
  - state variables
  - inheritance names
  - source ranges
  - function boundaries
  - basic call graph edges
  - external call sites
  - storage layout entries
  - source-map entries
- Added `NOT_ASSESSED` IR runs when solc AST/source-map artifacts are unavailable.
- Added deterministic external call inventory for `call`, `delegatecall`, `staticcall`, `callcode`, `transfer`, `send`, and detectable external member calls.
- Added finding-to-code enrichment without overwriting P1 evidence:
  - contract links
  - function links
  - external call site links
  - storage layout links when real storage labels are referenced
- Preserved P0/P1/P2A persistence, evidence, review, suppression, baseline, and SARIF workflows.
- Preserved analyzer failure semantics and partial completion behavior.

## Database Changes

New Prisma migration:

```text
packages/database/prisma/migrations/20260523213000_p2b_analysis_ir/migration.sql
```

Added enum:

```text
ExtractionStatus: EXTRACTED, PARTIAL, NOT_ASSESSED, FAILED
```

Added models:

```text
AnalysisIrRun
ContractSymbol
FunctionSymbol
ModifierSymbol
StateVariableSymbol
EventSymbol
CallGraphEdge
ExternalCallSite
StorageLayoutEntry
SourceMapEntry
FindingCodeLink
```

## API Endpoints

Repository-backed endpoints returning persisted DB rows only:

```text
GET /api/v1/scans/:scanId/ir-summary
GET /api/v1/scans/:scanId/contracts
GET /api/v1/scans/:scanId/contracts/:contractId/functions
GET /api/v1/scans/:scanId/call-graph
GET /api/v1/scans/:scanId/external-calls
GET /api/v1/scans/:scanId/storage-layout
GET /api/v1/findings/:findingId/code-links
```

## UI Changes

- Added report code intelligence panel.
- Shows IR status, contract/function counts, external call counts, contracts list, basic call graph list, external call sites, and storage layout table.
- Shows `NOT_ASSESSED` when real compiler artifacts are unavailable.
- Finding detail sidebar now shows persisted code links to contracts, functions, external calls, and storage layout entries.
- No static/demo graph or fabricated code intelligence is rendered.

## Tests Added

- solc offset conversion to line/column.
- AST extraction creates contract/function/event/state variable IR.
- Low-level call extraction creates external call sites and basic call graph edges.
- Storage layout extraction from real compiler output shape.
- Missing compiler artifact creates `NOT_ASSESSED` IR run.
- Worker persistence creates IR rows and finding code links from overlapping source ranges.
- API endpoints return repository-backed persisted IR data.

## Verification Completed

```bash
npm install
npm run db:generate
npm run typecheck
npm test
npm run build
```

`npm run db:generate` required elevated filesystem access on Windows because Prisma probes `C:\Users\nk148` outside the workspace.

## Commands

Install dependencies:

```bash
npm install
```

Generate Prisma client:

```bash
npm run db:generate
```

Run database migration in local development:

```bash
npm run db:migrate:dev
```

Deploy database migration in staging/production:

```bash
npm run db:deploy
```

Run API:

```bash
npm run dev:api
```

Run worker:

```bash
npm run dev:worker
```

Run web:

```bash
npm run dev:web
```

Run typecheck:

```bash
npm run typecheck
```

Run tests:

```bash
npm test
```

Build:

```bash
npm run build
```

## Limitations

- P2B does not compile projects or generate solc artifacts. It extracts IR only from real solc standard JSON/build-info-style artifacts already present in prepared artifacts.
- The call graph is intentionally named BasicCallGraph behavior. It is not a complete CFG.
- Source-map alignment is stored only when compiler source maps exist.
- Storage layout is stored only when compiler `storageLayout` output exists.
- Existing source preparation still excludes common build output directories, so P2B will usually report `NOT_ASSESSED` unless a supported solc JSON artifact is included in the prepared source input outside ignored directories.
- Finding-to-code links are enrichment only and do not modify original P1 evidence.

## Recommended P3

Implement analyzer expansion and a Foundry/compile/test runner: trusted compilation in sandboxed workers, compiler artifact capture, Foundry test execution, configurable build profiles, dependency cache controls, and SARIF/source-map alignment from generated artifacts.
