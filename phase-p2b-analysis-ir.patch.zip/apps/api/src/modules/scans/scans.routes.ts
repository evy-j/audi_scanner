import { Router } from "express";
import { authenticateJwtOrApiKey } from "../../common/middleware/api-key-auth.middleware.js";
import {
  requireOrganizationParam,
  requirePermissions
} from "../../common/middleware/authorize.middleware.js";
import { scanRateLimit } from "../../common/middleware/rate-limit.middleware.js";
import { validateRequest } from "../../common/validation/validate-request.js";
import { asyncHandler } from "../../common/middleware/async-handler.js";
import { auditLog } from "../../common/middleware/audit-log.middleware.js";
import {
  createScanSchema,
  listScansQuery,
  scanParams
} from "./scans.schemas.js";
import { organizationQuery } from "../../common/validation/common-schemas.js";
import { ScansController } from "./scans.controller.js";
import { FindingsController } from "../findings/findings.controller.js";
import { listScanFindingsQuery, scanFindingParams } from "../findings/findings.schemas.js";
import { ReviewController } from "../review/review.controller.js";
import {
  baselineComparisonQuery,
  reviewOrganizationQuery,
  sarifExportQuery
} from "../review/review.schemas.js";
import { AnalysisIrController } from "../analysis-ir/analysis-ir.controller.js";
import {
  irContractParams,
  irOrganizationQuery,
  irScanParams
} from "../analysis-ir/analysis-ir.schemas.js";

const controller = new ScansController();
const findingsController = new FindingsController();
const reviewController = new ReviewController();
const analysisIrController = new AnalysisIrController();

export const scanRoutes = Router();

scanRoutes.use(authenticateJwtOrApiKey);

scanRoutes.get(
  "/",
  validateRequest({ query: listScansQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:read"),
  asyncHandler(controller.list)
);

scanRoutes.post(
  "/",
  scanRateLimit,
  validateRequest({ body: createScanSchema }),
  requireOrganizationParam(),
  requirePermissions("scans:create"),
  auditLog("SCAN_START", "SCAN"),
  asyncHandler(controller.create)
);

scanRoutes.get(
  "/:scanId/findings",
  validateRequest({ params: scanFindingParams, query: listScanFindingsQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(findingsController.listByScan)
);

scanRoutes.get(
  "/:scanId/evidence-summary",
  validateRequest({ params: scanFindingParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(findingsController.evidenceSummary)
);

scanRoutes.get(
  "/:scanId/review-summary",
  validateRequest({ params: scanParams, query: reviewOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(reviewController.reviewSummary)
);

scanRoutes.get(
  "/:scanId/baseline-comparison",
  validateRequest({ params: scanParams, query: baselineComparisonQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(reviewController.baselineComparison)
);

scanRoutes.get(
  "/:scanId/export/sarif",
  validateRequest({ params: scanParams, query: sarifExportQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(reviewController.exportSarif)
);

scanRoutes.get(
  "/:scanId/ir-summary",
  validateRequest({ params: irScanParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.summary)
);

scanRoutes.get(
  "/:scanId/contracts/:contractId/functions",
  validateRequest({ params: irContractParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.functions)
);

scanRoutes.get(
  "/:scanId/contracts",
  validateRequest({ params: irScanParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.contracts)
);

scanRoutes.get(
  "/:scanId/call-graph",
  validateRequest({ params: irScanParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.callGraph)
);

scanRoutes.get(
  "/:scanId/external-calls",
  validateRequest({ params: irScanParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.externalCalls)
);

scanRoutes.get(
  "/:scanId/storage-layout",
  validateRequest({ params: irScanParams, query: irOrganizationQuery }),
  requireOrganizationParam(),
  requirePermissions("vulnerabilities:read"),
  asyncHandler(analysisIrController.storageLayout)
);

scanRoutes.get(
  "/:scanId",
  validateRequest({ params: scanParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:read"),
  asyncHandler(controller.get)
);

scanRoutes.post(
  "/:scanId/cancel",
  validateRequest({ params: scanParams, query: organizationQuery }),
  requireOrganizationParam(),
  requirePermissions("scans:cancel"),
  auditLog("SCAN_CANCEL", "SCAN"),
  asyncHandler(controller.cancel)
);
