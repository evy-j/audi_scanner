import { describe, expect, it } from "vitest";
import { promises as fs } from "node:fs";

describe("Prisma schema contract", () => {
  it("declares the scan persistence models", async () => {
    const schema = await fs.readFile("packages/database/prisma/schema.prisma", "utf8");

    expect(schema).toContain("model Scan ");
    expect(schema).toContain("model ScanTarget ");
    expect(schema).toContain("model Vulnerability ");
    expect(schema).toContain("model AuditReport ");
    expect(schema).toContain("@@index([status, priority, queuedAt])");
    expect(schema).toContain("enum FindingConfidenceState");
    expect(schema).toContain("model FindingEvidence ");
    expect(schema).toContain("model SourceRange ");
    expect(schema).toContain("model AnalyzerEvidence ");
    expect(schema).toContain("model FindingDecision ");
    expect(schema).toContain("model DetectorMetadata ");
    expect(schema).toContain("enum FindingReviewStatus");
    expect(schema).toContain("enum FindingReviewAction");
    expect(schema).toContain("model Project ");
    expect(schema).toContain("model FindingReview ");
    expect(schema).toContain("model FindingReviewEvent ");
    expect(schema).toContain("model FindingSuppressionRule ");
    expect(schema).toContain("model FindingBaseline ");
    expect(schema).toContain("model FindingComment ");
    expect(schema).toContain("model FindingAssignment ");
    expect(schema).toContain("model CodeOwnerRule ");
    expect(schema).toContain("enum ExtractionStatus");
    expect(schema).toContain("model AnalysisIrRun ");
    expect(schema).toContain("model ContractSymbol ");
    expect(schema).toContain("model FunctionSymbol ");
    expect(schema).toContain("model ModifierSymbol ");
    expect(schema).toContain("model StateVariableSymbol ");
    expect(schema).toContain("model EventSymbol ");
    expect(schema).toContain("model CallGraphEdge ");
    expect(schema).toContain("model ExternalCallSite ");
    expect(schema).toContain("model StorageLayoutEntry ");
    expect(schema).toContain("model SourceMapEntry ");
    expect(schema).toContain("model FindingCodeLink ");
  });
});
