import { PrismaClient } from "@prisma/client";

export function createTestPrismaClient(): PrismaClient {
  return new PrismaClient({
    datasources: {
      db: {
        url: process.env.DATABASE_URL
      }
    }
  });
}

export async function truncatePrismaTestData(prisma: PrismaClient): Promise<void> {
  await prisma.$transaction([
    prisma.auditLog.deleteMany(),
    prisma.apiKey.deleteMany(),
    prisma.auditReport.deleteMany(),
    prisma.findingCodeLink.deleteMany(),
    prisma.sourceMapEntry.deleteMany(),
    prisma.storageLayoutEntry.deleteMany(),
    prisma.externalCallSite.deleteMany(),
    prisma.callGraphEdge.deleteMany(),
    prisma.eventSymbol.deleteMany(),
    prisma.stateVariableSymbol.deleteMany(),
    prisma.modifierSymbol.deleteMany(),
    prisma.functionSymbol.deleteMany(),
    prisma.contractSymbol.deleteMany(),
    prisma.analysisIrRun.deleteMany(),
    prisma.findingReviewEvent.deleteMany(),
    prisma.findingComment.deleteMany(),
    prisma.findingAssignment.deleteMany(),
    prisma.findingBaseline.deleteMany(),
    prisma.findingReview.deleteMany(),
    prisma.findingSuppressionRule.deleteMany(),
    prisma.codeOwnerRule.deleteMany(),
    prisma.vulnerability.deleteMany(),
    prisma.scanTarget.deleteMany(),
    prisma.scan.deleteMany(),
    prisma.project.deleteMany(),
    prisma.contract.deleteMany(),
    prisma.subscription.deleteMany(),
    prisma.userRole.deleteMany(),
    prisma.rolePermission.deleteMany(),
    prisma.role.deleteMany(),
    prisma.permission.deleteMany(),
    prisma.organizationMember.deleteMany(),
    prisma.organization.deleteMany(),
    prisma.session.deleteMany(),
    prisma.wallet.deleteMany(),
    prisma.user.deleteMany(),
    prisma.chain.deleteMany()
  ]);
}
